<?php
    include("connection.php");
    $id = isset($_GET['id'])?$_GET['id']:0;
    $sql="select machine_name,description from tbl_machine WHERE id=$id";
    $result=$db->query($sql);
    // print_r($result);
    $mn="";
    $dsc="";
    if ($result->num_rows){
        $row = $result->fetch_assoc();
        // $id = $_GET['id'];
        $mn = $row['machine_name'];
        $dsc= $row['description'];
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>tutorial11</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <h2 style="text-align:center" >form</h2>
</head>
<body>
    <div class="container">
       <form action="insert.php" method="get">
           <div class="form-group ">
               <!-- <label for="id">id</label>-->
               <input type="hidden" name="id" class="form-control" value="<?=$id?>"><br>

               <label for="machine name">machine name</label>
               <input type="text" name="machine_name" class="form-control mt-2" value="<?=$mn?>"><br>

               <label for="dsc">description</label>
               <input type="text" name="description" class="form-control mt-2" value="<?=$dsc?>"><br>

               <input type="submit" value="submit" class="btn btn-primary"> 

           </div>
        
       </form>
    </div>
</body>
</html>