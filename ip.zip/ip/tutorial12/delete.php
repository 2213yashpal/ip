<?php
include("connection.php");
    $i=$_GET['id'];
echo $i;
    $sql="DELETE FROM tbl_machine WHERE id = $i";
    $result=$db->query($sql);

    header("Location:index.php");

    // if($result){
    //     echo "data inserted";
    // } 
    // else{
    //     echo "data not inserted";
    // }
?>