<?php

    $db=new mysqli("localhost","root","","tutorial10");

    // if($db){
    //     echo "connection successfully";
    // }
    // else{
    //     echo "connection failed";
    // }

?>