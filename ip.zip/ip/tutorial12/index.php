<?php
    include("connection.php");
    $sql="select * from tbl_machine";
    $result=$db->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>tutorial11</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <span style="float:right" class="btn btn-light">
            <a href="form.php">Add New Record</a>
        </span>
        <table class="table table-striped table-bordered">
            <thead>
                <tr id="header">
                    <th>Id</th>
                    <th>Machine_name</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows){
                    while ($row = $result->fetch_assoc()){
                ?>
                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['machine_name']; ?></td>
                    <td><?= $row['description'];?></td>
                    <td>
                        <span class="btn btn-light">
                            <a href="form.php?id=<?= $row['id']; ?>">edit</a>
                        </span>

                        <span class="btn btn-light">
                            <a id="" href="delete.php?id=<?= $row['id'];?>">delete</a>
                        </span>

                    </td>
                </tr>
                <?php
                        }
                    }
                else{
                    echo "no record found";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>