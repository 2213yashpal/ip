<?php
include("connection.php");
    $i=$_GET['id'];
    $n=$_GET['machine_name'];
    $d=$_GET['description'];

    echo $i, $n, $d;
    if($i==0){
    $sql="insert into tbl_machine(machine_name, description) values('$n','$d')";
    }
    else{
        $sql="UPDATE tbl_machine SET machine_name='$n', description='$d' WHERE id=$i";
    }
    $result=$db->query($sql);

    header("Location:index.php");

    // if($result){
    //     echo "data inserted";
    // } 
    // else{
    //     echo "data not inserted";
    // }
?>


