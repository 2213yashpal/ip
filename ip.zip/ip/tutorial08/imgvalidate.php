<?php
session_start();
$message='';
if(isset($_POST['uploadbtn']) && $_POST['uploadbtn']=='Upload') {
    if(isset($_FILES['uploadedfile']) && $_FILES['uploadedfile']['error']== UPLOAD_ERR_OK){
        
        $fileTmpPath = $_FILES['uploadedfile']['tmp_name'];
        $fileName = $_FILES['uploadedfile']['name'];
        $fileSize = $_FILES['uploadedfile']['size'];
        $fileType = $_FILES['uploadedfile']['type'];
        $fileNameCmps = explode('.',$fileName);
        $fileExtention = strtolower(end($fileNameCmps));

        $newFilename = md5(time().$fileName) . '.' . $fileExtention;
        $extentionlist = array('jpg','gif','svg','png');
        if(in_array($fileExtention,$extentionlist)) 
        {
            $uploaddir="./uploads/";
            $des_path = $uploaddir.$newFilename;
            if(move_uploaded_file($fileTmpPath,$des_path)){
                $message='file uploaded sucessfully';
            }
            else{
                $message = 'there is problem in uploading file';
            }
        }else{
            $message ='allowed file extention are jpg,gif,svg,png';
        }
    }
}
else{
    $message ="there is some error in file upload";
}
$_SESSION['message']=$message;
header('Location:index.php');
?>