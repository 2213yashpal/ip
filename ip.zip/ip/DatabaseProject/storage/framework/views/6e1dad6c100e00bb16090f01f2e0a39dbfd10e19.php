<?php if(isset($data)): ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(url('demo/'.$z->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field("PUT"); ?>
    <input type="text" name="name" value="<?php echo e($z->name); ?>" ><br><br>
    <input type="text" name="email" value="<?php echo e($z->email); ?>"><br><br>
    <input type="submit" value="submit">
    
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
<form action="<?php echo e(url('demo')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="name" ><br><br>
    <input type="text" name="email"><br><br>
    <input type="submit" value="submit">
</form>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\DatabaseProject\resources\views/avi/edit.blade.php ENDPATH**/ ?>