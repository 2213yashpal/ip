<a href="<?php echo e(url('demo/create')); ?>">
  <button>insert data</button>
</a>

<br><br>

<table border="1">
  <tr>
    <th>id</th>
    <th>name</th>
    <th>pass</th>
    <th>Action</th>
  </tr>

  <?php $__currentLoopData = $d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($value->id); ?></td>
    <td><?php echo e($value->name); ?></td>
    <td><?php echo e($value->email); ?></td>
    <td>
        <a href="<?php echo e(url('demo/'.$value->id.'/edit')); ?>" class="href">Edit</a>
        <form action="<?php echo e(url('demo/'.$value->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <input type="submit" value="Delete">
        </form>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


<?php /**PATH C:\xampp\htdocs\Laravel\DatabaseProject\resources\views/avi/index.blade.php ENDPATH**/ ?>