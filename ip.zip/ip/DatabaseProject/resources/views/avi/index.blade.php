<a href="{{url('demo/create')}}">
  <button>insert data</button>
</a>

<br><br>

<table border="1">
  <tr>
    <th>id</th>
    <th>name</th>
    <th>pass</th>
    <th>Action</th>
  </tr>

  @foreach($d as $value)
  <tr>
    <td>{{$value->id}}</td>
    <td>{{$value->name}}</td>
    <td>{{$value->email}}</td>
    <td>
        <a href="{{url('demo/'.$value->id.'/edit')}}" class="href">Edit</a>
        <form action="{{url('demo/'.$value->id)}}" method="post">
          @csrf
          @method('DELETE')
          <input type="submit" value="Delete">
        </form>
    </td>
  </tr>
  @endforeach
</table>


