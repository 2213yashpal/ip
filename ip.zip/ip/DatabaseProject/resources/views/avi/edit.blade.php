@if(isset($data))
@foreach($data as $z)
<form action="{{url('demo/'.$z->id)}}" method="post">
    @csrf
    @method("PUT")
    <input type="text" name="name" value="{{$z->name}}" ><br><br>
    <input type="text" name="email" value="{{$z->email}}"><br><br>
    <input type="submit" value="submit">
    
</form>
@endforeach

@else
<form action="{{url('demo')}}" method="post">
    @csrf
    <input type="text" name="name" ><br><br>
    <input type="text" name="email"><br><br>
    <input type="submit" value="submit">
</form>
@endif