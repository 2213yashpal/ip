<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class insertdata extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    DB::table('mydata')->insert(['name'=>'asd', 'email'=>'abc@m.com', 'age'=>20]);
    DB::table('mydata')->insert(['name'=>'asdf', 'email'=>'abc@m.com', 'age'=>20]);
    DB::table('mydata')->insert(['name'=>'asdfh', 'email'=>'abc@m.com', 'age'=>20]);
    DB::table('mydata')->insert(['name'=>'asdfhj', 'email'=>'abc@m.com', 'age'=>20]);
    DB::table('mydata')->insert(['name'=>'asdfhjk', 'email'=>'abc@m.com', 'age'=>20]);
    }
}
