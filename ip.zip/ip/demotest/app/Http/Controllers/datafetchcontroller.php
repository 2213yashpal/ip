<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class datafetchcontroller extends Controller
{
    //
    function fetchdata() {
        $data = DB::table('mydata')->get();
        return view('showdataview', ['data'=>$data]);
    }
}
