<?php
$data = $_GET['datavalue'];

$a = array('Hetvi', 'Sahil', 'Chelsi', 'Ashish', 'Priyal', 'Nirali');

$flag=false;
foreach($a as $name) {
    if($data == $name){
        $flag=true;
        break;
    }
}
if($flag){
    echo "<p style='color:green;font-weight: bold;'>Entered name found in the predefined array.</p>";
}
else{
    echo "<p style='color:red;font-weight: bold;'>Entered name not found in the array.</p>";
}
?>    