<?php

$db = new mysqli("localhost", "root", "", "gd_gallery");

$sql = "select * from gd_gallery_sub where isdelete=0";

$result = $db->query($sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>psee</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
 -->

</head>

<body>
    <div class="table-responsive container">
        <span style="float:right" class="btn btn-light">
            <a href="form.php">Add New Record</a>
        </span>
        <table class="table table-striped table-bordered">
            <thead>
                <tr id="header">
                    <th>id</th>
                    <th>gallery_name</th>
                    <th>gallery_images</th>
                    <th>updated_on</th>
                    <th>created_on</th>
                    <th style="text-align:center">action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows) {
                    while ($row = $result->fetch_assoc()) {
                ?>
                        <tr>
                            <td><?= $row['id']; ?></td>
                            <td><?= $row['gallery_name']; ?></td>
                            <td><img src="<?= $row['gallery_images']; ?>" height="100px" width="150px"></td>
                            
                            <td><?= $row['updated_on']; ?></td>
                            
                            <td><?= $row['created_on']; ?></td>
                            <td>
                                <span class="btn btn-light">
                                    <a href="form.php?id=<?= $row['id']; ?>">edit</a>
                                </span>
                                <span class="btn btn-secondary">
                                    <a id="" href="delete.php?id=<?= $row['id']; ?>">delete</a>
                                </span>
                        </tr>
                <?php
                    }
                } else {
                    echo "no records found";
                }

                ?>

            </tbody>
        </table>
    </div>
</body>

</html>