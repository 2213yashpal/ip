<?php

$db=new mysqli("localhost","root","","gd_gallery");

?>