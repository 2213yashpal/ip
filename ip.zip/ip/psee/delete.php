<?php
include("connection.php");
    $i=$_GET['id'];
echo $i;
    // $sql="DELETE FROM gd_gallery_sub WHERE id = $i";
    $sql="UPDATE gd_gallery_sub SET isdelete=1 WHERE id=$i";
    $result=$db->query($sql);

    //header("Location:index.php");

?>