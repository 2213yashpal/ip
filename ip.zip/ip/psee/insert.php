<?php
include("connection.php");
    $i=$_POST['id'];
    $n=$_POST['gallery_name'];
    $d="albums/".$_FILES['gallery_images']['name'];
    $tmp=$_FILES['gallery_images']['tmp_name'];

    if($i==0){
    $sql="insert into gd_gallery_sub(gallery_name, gallery_images, created_by) values('$n','$d', 1)";
    }
    else{
        $sql="UPDATE gd_gallery_sub SET gallery_name='$n', gallery_images='$d', updated_by=1 WHERE id=$i";
    }
    
    if($db->query($sql)) {
        // echo 11;
        move_uploaded_file($tmp,$d);
    }

    header("Location:index.php");    