<?php
    include("connection.php");
    $id = isset($_GET['id'])?$_GET['id']:0;
    $sql="select gallery_name,gallery_images from gd_gallery_sub WHERE id=$id";
    $result=$db->query($sql);
    // print_r($result);
    $mn="";
    $dsc="";
    if ($result->num_rows){
        $row = $result->fetch_assoc();
        // $id = $_GET['id'];
        $mn = $row['gallery_name'];
        $dsc= $row['gallery_images'];
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <h2 style="text-align:center" >form</h2>
</head>
<body>
    <div class="container">
       <form action="insert.php" method="post" enctype="multipart/form-data">
           <div class="form-group ">
               <!-- <label for="id">id</label>-->
               <input type="hidden" name="id" class="form-control" value="<?=$id?>"><br>

               <label for="gallery_name">gallery name </label>
               <input type="text" name="gallery_name" class="form-control mt-2" value="<?=$mn?>"><br>

               <label for="dsc">gallery images</label>
               <input type="file" name="gallery_images" class="form-control mt-2" value="<?=$dsc?>"><br>

               <input type="submit" value="submit" class="btn btn-primary"> 

           </div>
        
       </form>
    </div>
</body>
</html>