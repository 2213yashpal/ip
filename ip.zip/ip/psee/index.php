<?php

$db = new mysqli("localhost", "root", "", "gd_gallery");

$sql = "select * from gd_gallery_sub where isdelete=0";

$result = $db->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>psee</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script>
        // $(document).ready(function () {
        // $('.btnn').hide();
        // $('.myimg').hover( function() { $('.btnn').toggle(); } );
        // });
        
    </script>
</head>

<body>
    <div class="container">
        <span style="float:center" class="btn btn-light mt-4">
            <a href="form.php">Upload Image</a> 
        </span>
        </br>
        <div class="row">
            <?php
            if ($result->num_rows) {
                while ($row = $result->fetch_assoc()) {
                    
            ?>
                <div class="col-md-3 column" id="<?php echo $row['id']; ?>">
                    <img src="<?= $row['gallery_images']; ?>" height="255" width="255px" class="mt-5">
                        <a class="btn-sm btn-secondary col-sm-6" href="form.php?id=<?= $row['id']; ?>" style="float:left">edit</a>
                        <a class="btn-sm btn-dark col-sm-6" style="float:right" onclick="delet(<?php echo $row['id']; ?>)">delete</a>
                </div>
            <?php
                }
            } else {
                echo "no records found";
            }
            ?>
        </div>
    </div>

<script>
function delet(id) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", "delete.php?id=" + id,true);
    xmlhttp.send();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            $("#" + id).hide();
        };
    };
};
</script>    
</body>

</html>